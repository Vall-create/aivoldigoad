# Halaman Raja untuk GitHub Pages (tanpa server)

## Pasang
1. Taruh index.html dan .nojekyll di AKAR repo GitHub (bukan di dalam folder).
2. Repo > Settings > Pages > Source: Deploy from a branch > main > / (root) > Save.
3. Buka https://NAMAMU.github.io/NAMAREPO/ (tunggu 1-2 menit).

## Panel admin (tanpa sandi)
Buka dengan #admin di link, atau ketuk judul 5x cepat.

### Supaya tombol Simpan semua berfungsi
Kartu "Simpan ke GitHub": isi token + repo (pemilik/nama), tekan Simpan pengaturan, lalu Cek koneksi.
Token: GitHub > Settings > Developer settings > Personal access tokens > Fine-grained tokens > pilih repo ini > Permissions > Contents: Read and write.
Perubahan jadi commit di repo; pengunjung melihatnya setelah GitHub Pages memperbarui (1-10 menit).

### Supaya AI menjawab
Kartu "Kunci API AI": pilih penyedia (atau Otomatis), tempel key, Simpan dan tes.
Key hanya disimpan di browser perangkat itu (tidak ke GitHub), jadi asisten menjawab di perangkat tempat key dimasukkan.
GitHub Pages tidak punya server untuk menyembunyikan key. JANGAN menaruh key di file di repo: GitHub/penyedia akan mencabutnya otomatis.
Penyedia yang bisa dipanggil langsung dari browser: Claude (sk-ant-), OpenAI, Groq, OpenRouter, Gemini, DeepSeek. GitHub Models bisa saja diblokir CORS.
